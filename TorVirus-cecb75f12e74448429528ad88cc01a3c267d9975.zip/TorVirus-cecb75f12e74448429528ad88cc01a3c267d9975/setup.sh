random_task_message() {
    echo "[INFO] $(shuf -n 1 lib/msg.txt)"
}

random_task_message
apt install golang python3-pip nodejs npm -y > /dev/null 2>&1

random_task_message
chmod +x root/root.py > /dev/null 2>&1

random_task_message
pip install cryptography pystyle colorama httpx tqdm beautifulsoup4 bs4 googlesearch-python> /dev/null 2>&1

random_task_message
npm install --prefix=bin/odd/.cache/ hpack colors axios user-agents header-generator --force > /dev/null 2>&1